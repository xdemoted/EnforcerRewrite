export enum Rating {
    SAFE = "safe",
    SUGGESTIVE = "suggestive",
    BORDERLINE = "borderline",
    EXPLICIT = "explicit"
}