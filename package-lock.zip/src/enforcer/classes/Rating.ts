export enum Rating {
    SAFE = "SAFE",
    SUGGESTIVE = "SUGGESTIVE",
    BORDERLINE = "BORDERLINE",
    EXPLICIT = "EXPLICIT"
}