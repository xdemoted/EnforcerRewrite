import { ApplicationIntegrationType, InteractionContextType, RESTPostAPIChatInputApplicationCommandsJSONBody, SlashCommandBuilder, CommandInteraction, GuildMember, EmbedBuilder, ContextMenuCommandBuilder, ApplicationCommandType, RESTPostAPIContextMenuApplicationCommandsJSONBody, ContextMenuCommandInteraction } from "discord.js";
import BaseCommand from "src/general/classes/BaseCommand";
import { Main } from "src/enforcer/Main";
import { Singleton } from "src/container/Singleton";

@Singleton
export class MenuBan extends BaseCommand {
    public override restricted = true;

    public getCommand(): RESTPostAPIContextMenuApplicationCommandsJSONBody {
        return new ContextMenuCommandBuilder()
            .setName("ban")
            .setDefaultMemberPermissions(0) // Requires admin permissions
            .setIntegrationTypes([ApplicationIntegrationType.GuildInstall])
            .setContexts([InteractionContextType.Guild])
            .setType(ApplicationCommandType.User)
            .toJSON();
    }

    public async execute(interaction: ContextMenuCommandInteraction): Promise<void> {
        const guild = interaction.guild;

        if (!guild) {
            await interaction.editReply({ content: "This command can only be used in a guild." });
            return;
        }

        const member = interaction.options.get("user")?.member;

        if (!member||!(member instanceof GuildMember)) {
            await interaction.editReply({ content: "User not found." });
            return;
        }

        if (!member.bannable) {
            await interaction.editReply({ content: "Bot cannot ban this user." });
            return;
        }

        const highestRole = (interaction.member as GuildMember).roles.highest;
        const targetHighestRole = member.roles.highest;

        if (highestRole.position <= targetHighestRole.position) {
            await interaction.editReply({ content: "You cannot ban this user because they have a higher or equal role." });
            return;
        }

        await member.ban({ reason: `Banned by ${interaction.user.tag} for reason: Not Provided` });

        const embed = new EmbedBuilder()
            .setTitle("User Banned")
            .setDescription(`**User:** ${member.user.tag}\n**Banned by:** ${interaction.user.tag}\n**Reason:** Not Provided`)
            .setColor(0xff0000)
            .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        return;
    }
}