import { ApplicationIntegrationType, InteractionContextType, RESTPostAPIChatInputApplicationCommandsJSONBody, SlashCommandBuilder, CommandInteraction, GuildMember, EmbedBuilder } from "discord.js";
import BaseCommand from "src/general/classes/BaseCommand";
import { Main } from "src/enforcer/Main";
import { Singleton } from "src/container/Singleton";

@Singleton
export class Warn extends BaseCommand {
    public override restricted = true;
    public getCommand(): RESTPostAPIChatInputApplicationCommandsJSONBody {
        return new SlashCommandBuilder()
            .setName("warn")
            .setDescription("Warn another user")
            .addUserOption(option =>
                option.setName("user")
                    .setDescription("User to warn")
                    .setRequired(true)
            )
            .addStringOption(option =>
                option.setName("reason")
                    .setDescription("Reason for warn")
                    .setMinLength(5)
                    .setRequired(true)
            )
            .setDefaultMemberPermissions(0) // Requires admin permissions
            .setIntegrationTypes([ApplicationIntegrationType.GuildInstall])
            .setContexts([InteractionContextType.Guild])
            .toJSON();
    }

    public async execute(interaction: CommandInteraction): Promise<void> {
        const guild = interaction.guild;

        if (!guild) {
            await interaction.editReply({ content: "This command can only be used in a guild." });
            return;
        }

        const member = interaction.options.get("user")?.member;

        if (!member||!(member instanceof GuildMember)) {
            await interaction.editReply({ content: "User not found." });
            return;
        }

        if (!member.moderatable) {
            await interaction.editReply({ content: "Bot cannot warn this user." });
            return;
        }

        const highestRole = (interaction.member as GuildMember).roles.highest;
        const targetHighestRole = member.roles.highest;

        if (highestRole.position <= targetHighestRole.position) {
            await interaction.editReply({ content: "You cannot warn this user because they have a higher or equal role." });
            return;
        }

        const reason = interaction.options.get("reason")?.value as string;

        await member.ban({ reason: `Warned by ${interaction.user.tag} for reason: ${reason}` });

        const embed = new EmbedBuilder()
            .setTitle("User Warned")
            .setDescription(`**User:** ${member.user.tag}\n**Warned by:** ${interaction.user.tag}\n**Reason:** ${reason}`)
            .setColor(0xff0000)
            .setTimestamp();
        await interaction.editReply({ embeds: [embed] });
        return;
    }
}