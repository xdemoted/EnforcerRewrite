import { ApplicationIntegrationType, InteractionContextType, RESTPostAPIChatInputApplicationCommandsJSONBody, SlashCommandBuilder, CommandInteraction, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, Colors, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, User, Guild, GuildMember } from "discord.js";
import BaseCommand from "../../general/classes/BaseCommand";
import { Main } from "../Main";
import UserHandler from "../handlers/UserHandler";
import nodeHtmlToImage from "node-html-to-image";
import fs from "fs";
import GeneralUtils from "src/general/utils/GeneralUtils";
import { Singleton } from "src/container/Singleton";

@Singleton
export class Level extends BaseCommand {
    private userHandler: UserHandler;

    public constructor(userHandler: UserHandler) {
        super();
        this.userHandler = userHandler;
    }

    public getCommand(): RESTPostAPIChatInputApplicationCommandsJSONBody {
        return new SlashCommandBuilder()
            .setName("level")
            .setDescription("Display your level card.")
            .setIntegrationTypes([ApplicationIntegrationType.GuildInstall])
            .setContexts([InteractionContextType.PrivateChannel, InteractionContextType.Guild])
            .toJSON();
    }

    public async execute(interaction: CommandInteraction): Promise<void> {
        const user = await this.userHandler.getUser(interaction.user.id);
        const discordUser = interaction.user;
        let levelCard = await nodeHtmlToImage({
          html: fs.readFileSync('src/enforcer/web/level.html', 'utf8'),
          selector: 'body > div',
          content: {
            username: discordUser.displayName,
            level_card_bg: "https://files.catbox.moe/fzx1xz.png",
            avatar_url: discordUser.displayAvatarURL({ size: 1024, extension: 'webp' }),
            level: user.getLevel(),
            xp: user.getLevelProgress(),
            xp_required: GeneralUtils.getXPForLevel(user.getLevel() + 1)
          },
          puppeteerArgs: {
            args: ['--no-sandbox', '--disable-setuid-sandbox']}
        });

        
        levelCard = Array.isArray(levelCard) ? levelCard[0] : levelCard;

        interaction.editReply({ files: [{ attachment: levelCard, name: 'level_card.png' }] });
        return;
    }
}