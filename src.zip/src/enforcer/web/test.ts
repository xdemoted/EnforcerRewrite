import WebHandler from "../handlers/WebHandler";

new WebHandler()

setTimeout(() => {
    // Keep Alive
}, 30000);
